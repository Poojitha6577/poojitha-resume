// Contact Button Click Alert
function contactAlert() {
    alert("Thank you for reaching out! 🚀✨ I will get back to you soon!");
  }
  
  // Fade-in Scroll Animation
  const faders = document.querySelectorAll('.fade-in');
  
  const appearOptions = {
    threshold: 0.3,
    rootMargin: "0px 0px -50px 0px"
  };
  
  const appearOnScroll = new IntersectionObserver(function(entries, appearOnScroll) {
    entries.forEach(entry => {
      if (!entry.isIntersecting) {
        return;
      } else {
        entry.target.classList.add('appear');
        appearOnScroll.unobserve(entry.target);
      }
    });
  }, appearOptions);
  
  faders.forEach(fader => {
    appearOnScroll.observe(fader);
  });
  